Quality of life shortcuts for WISEflow.

# Install
- Clone repo
- In chrome, go to *More tools > Extension*
- Set to "Developer mode" in the top right corner.
- Click "Load unpacked" and navigate to the repo. Click "Select folder".

# Usage

Change shortcuts in Extensions > Tool menu (top left) > Keyboard Shortcuts.
